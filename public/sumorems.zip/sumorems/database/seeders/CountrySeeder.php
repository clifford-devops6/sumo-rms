<?php

namespace Database\Seeders;

use App\Models\Country;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CountrySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Country::truncate();
        $countries = [
            ['name' => 'Kenya', 'code' => 'KE','prefix'=>254],
            ['name' => 'Uganda', 'code' => 'UG','prefix'=>256],
            ['name' => 'Tanzania', 'code' => 'TZ','prefix'=>255],

        ];
        foreach ($countries as $key => $value) {
            Country::create($value);
        }
    }
}
