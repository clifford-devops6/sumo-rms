<?php

namespace Database\Seeders;

use App\Models\PaymentPeriod;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PaymentPeriodSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        PaymentPeriod::truncate();
        $periods=[
            ['name'=>'weekly','number_of_days'=>7],
            ['name'=>'monthly','number_of_days'=>30],
            ['name'=>'semiannually','number_of_days'=>183],
            ['name'=>'annually','number_of_days'=>365],
            ['name'=>'biannually','number_of_days'=>730]
        ];

        foreach ($periods as $period){
            PaymentPeriod::create($period);
        }


    }
}
