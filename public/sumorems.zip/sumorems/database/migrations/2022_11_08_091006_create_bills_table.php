<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bills', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->unsignedBigInteger('company_id')->unsigned();
            $table->unsignedBigInteger('lease_id')->unsigned();
            $table->unsignedBigInteger('payment_id')->unsigned()->nullable();
            $table->float('amount',8,2);
            $table->string('status')->comment('Paid/Unpaid');
            $table->integer('billable_id');
            $table->string('billable_type');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bills');
    }
};
