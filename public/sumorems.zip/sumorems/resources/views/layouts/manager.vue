<script setup lang="ts">
import { InertiaProgress } from '@inertiajs/progress'
InertiaProgress.init()
import {Link} from "@inertiajs/inertia-vue3";
import ResourceBlock from "@/views/components/resource-block.vue";
</script>
<template>
    <div class="relative min-h-screen">
        <div class="flex">
            <div class="relative" style="background-color: #687687;">
                <aside class="w-64 top-0" >
                    <div class="fixed w-64" >

                        <div class=" w-full" >
                            <div class="mt-24">
                                <ul>
                                    <li class="">
                                        <Link href="#">
                                            <div class="hover:bg-gray-400 w-full  py-2">
                                                <p class="font-light tracking-wide text-lg text-white"> <span class="mr-3 text-sky-800"></span>Dashboard</p>
                                            </div>
                                        </Link>

                                    </li>
                                    <li>
                                        <Link href="#">
                                            <div class="hover:bg-gray-400 w-full  py-2">
                                                <p class="font-light tracking-wide text-lg text-white"> <span class="mr-3 text-sky-800"></span>Dashboard</p>
                                            </div>
                                        </Link>

                                    </li>
                                    <li>
                                        <Link href="#">
                                            <div class="hover:bg-gray-400 w-full  py-2">
                                                <p class="font-light tracking-wide text-lg text-white"> <span class="mr-3 text-sky-800"></span>Dashboard</p>
                                            </div>
                                        </Link>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </aside>
            </div>

            <div class="bg-white w-full min-h-screen pb-5">

                <div>
                    <slot/>
                </div>

            </div>

        </div>
    </div>


</template>




