<template>
<admin>
    <Head>
        <title>{{company.name}}</title>
    </Head>
    <admin-navbar>
        <template #header> {{company.name}}</template>
    </admin-navbar>
    <div class="pt-14">

        <div class="grid lg:grid-cols-4">

            <div class="lg:col-span-1 p-5 grid border">
                <div class="rounded-full mt-5">
                    <img :src="company.image">

                </div>
                <div class="text-center mt-5">
                    <h6 class="capitalize font-bold text-md">{{company.name}}</h6>


                </div>
            </div>
            <div class="lg:col-span-3 grid">
                <div class="border overflow-hidden">
                    <div class="border-b py-5 px-5 bg-sky-50">
                        <h1 class="font-bold text-md text-sumo-800">Company Details</h1>
                    </div>
                    <div class="py-5 px-5">
                     <div class="flex gap-8">
                         <div>
                             <p class="font-semibold py-1"><span class="text-sumo-800">Contact Person:</span> {{company.contact_person}}</p>
                             <p class="font-semibold py-1"><span class="text-sumo-800">Email:</span> {{company.email}}</p>
                             <p class="font-semibold py-1"><span class="text-sumo-800">Cellphone:</span> {{company.cellphone}}</p>
                         </div>
                         <div>
                             <p class="font-semibold py-1"><span class="text-sumo-800">Country:</span> {{company.location.country.name}}</p>
                             <p class="font-semibold py-1"><span class="text-sumo-800">City:</span> {{company.location.city}}</p>
                             <p class="font-semibold py-1"><span class="text-sumo-800">Street Address:</span> {{company.location.street_address}}</p>
                         </div>
                     </div>
                    </div>
                </div>

                <div class="border">
                    <div class="border-b py-5 px-5 bg-sky-50">
                        <h1 class="font-bold text-md text-sumo-800">Manager Details</h1>
                    </div>
                    <div class="py-5 px-5">
                       <div class="flex gap-8">
                           <div>
                               <p class="font-semibold py-1"><span class="text-sumo-800">Manager:</span> {{company.manager.name}} {{company.manager.last_name}}</p>
                               <p class="font-semibold py-1"><span class="text-sumo-800">Manager ID:</span> {{company.manager.user_code}}</p>

                           </div>
                           <div>

                               <p class="font-semibold py-1"><span class="text-sumo-800">Cellphone:</span> {{company.manager.cellphone}}</p>
                               <p class="font-semibold py-1"><span class="text-sumo-800">Email:</span> {{company.manager.email}}</p>
                           </div>
                       </div>

                    </div>
                </div>
            </div>

        </div>
    </div>

    <template #sidebar>
        <admin-nav-link :href="'/admin/companies/'+company.slug+'/edit'">
            <p><span class="mr-2 text-sky-800"><i class="far fa-angle-right"></i></span>Edit Details</p>
        </admin-nav-link>
    </template>
</admin>
</template>

<script setup lang="ts">
import Admin from "@/views/layouts/admin.vue";
import {Head} from "@inertiajs/inertia-vue3";
import AdminNavbar from "@/views/components/admin-navbar.vue";
import AdminNavLink from "@/views/components/admin-nav-link.vue";
defineProps({
    company:Object
})
</script>

<style scoped>

</style>
