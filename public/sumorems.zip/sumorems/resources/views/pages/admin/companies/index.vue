<template>
    <admin>
        <Head>
            <title>All Companies</title>
        </Head>
        <admin-navbar>
            <template #header>Companies</template>
        </admin-navbar>
        <div class="pb-8">
            <div class="bg-sky-50 p-5 flex justify-between ">
                <p>
                    <span class="text-sky-800 mr-2"><i class="fas fa-info-circle"></i></span>
                    All companies that exist in the database
                </p>
            </div>

            <div class="border">
                <!--table search and name-->
                <div class="flex justify-between px-3 py-3">
                    <div>
                        <h6 class="font-bold">Companies ({{companies.data.length}})</h6>

                    </div>

                    <div class=" mr-5">

                        <div class="relative">
                            <div class="flex absolute inset-y-0 left-0 items-center pl-3 pointer-events-none">
                                <svg aria-hidden="true" class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none"
                                     stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                          d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                </svg>
                            </div>
                            <input v-model="search" type="search" id="default-search"
                                   class="block p-3 pl-10 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-sky-600 focus:border-sky-600"
                                   placeholder="Search roles..." required>

                        </div>
                    </div>
                </div>

                <table class="table-auto w-full mt-3 border-t">
                    <thead>
                    <tr class="bg-gray-100 h-14 text-sky-800">
                        <th class="text-start py-3 px-4">Id</th>
                        <th class="text-start py-3 px-4">Name</th>
                        <th class="text-start py-3 px-4">Manager</th>
                        <th class="text-start py-3 px-4">Email</th>
                        <th class="text-start py-3 px-4">Cellphone</th>
                        <th class="text-end py-3 px-4">Action</th>


                    </tr>
                    </thead>
                    <tbody>
                    <tr class="border-b" v-if="companies.data.length" v-for="company in companies.data" :key="company.id">
                        <td class="py-3 px-4">{{ company.id }}</td>
                        <td class="py-3 px-4">{{ company.name }}</td>
                        <td class="py-3 px-4">{{company.manager.name }}</td>
                        <td class="py-3 px-4">{{ company.email}}</td>
                        <td class="py-3 px-4">{{ company.cellphone}}</td>
                        <td class="py-3 px-4 text-end">
                            <div class="dropdown dropdown-end">
                                <label tabindex="0" class="cursor-pointer hover:text-sky-800"> Action <span class="ml-2"><i
                                    class="fal fa-ellipsis-v-alt"></i></span></label>
                                <ul tabindex="0" class="dropdown-content   shadow-md bg-sky-50 rounded-md divide-y w-44">
                                    <li class="text-start">
                                        <Link :href="'/admin/companies/'+company.slug"
                                              method="get" as="button"
                                              class="font-semibold hover:text-sky-800 text-sm py-3 px-3">
                                            <span class="mr-1"><i class="fal fa-bookmark"></i></span>Details</Link>
                                    </li>

                                    <li class="text-start">
                                        <Link :href="'/admin/companies/'+company.slug+'/edit'"
                                              method="get" as="button"
                                              class="font-semibold hover:text-sky-800 text-sm py-3 px-3">
                                            <span class="mr-1"><i class="fal fa-pencil"></i></span>Edit</Link>
                                    </li>

                                </ul>
                            </div>
                        </td>

                    </tr>
                    <tr v-else>
                        <td colspan="5" class="py-3 px-4">No Company data available</td>
                    </tr>



                    </tbody>

                </table>
                <div class="bg-gray-100 p-3 flex justify-between">
                    <div class="self-center">
                        <h6 class="font-medium">Showing <span class="text-sky-800">{{ companies.meta.current_page }}</span> of
                            <span
                                class="text-sky-800">{{ companies.meta.last_page }}</span> Page(s)</h6>
                    </div>
                    <div class="flex" >
                        <Link :href="companies.links.prev" class="btn-primary text-xs m-1"
                              v-if="companies.links.prev" ><span
                            class="mr-2"><i class="far fa-angle-left"></i></span>Prev
                        </Link>
                        <Link :href="companies.links.next" class="btn-primary text-xs m-1" v-if="companies.links.next">
                            Next
                            <span class="ml-2"><i class="far fa-angle-right"></i></span></Link>

                    </div>

                </div>
            </div>
        </div>
        <template #sidebar>
            <admin-nav-link href="/admin/data/create">
                <p><span class="mr-2 text-sky-800"><i class="far fa-angle-right"></i></span>Create a Company</p>
            </admin-nav-link>
        </template>
    </admin>
</template>

<script setup lang="ts">
import Admin from "@/views/layouts/admin.vue";
import AdminNavbar from "@/views/components/admin-navbar.vue";
import {Head} from "@inertiajs/inertia-vue3";
import {Link} from "@inertiajs/inertia-vue3";
import {ref, watch} from "vue";
import {Inertia} from "@inertiajs/inertia";
import _ from "lodash"
import AdminNavLink from "@/views/components/admin-nav-link.vue";
let props=defineProps({
    companies:Object,
    filters:Object,
})

let search=ref(props.filters.search)
watch(search, _.debounce(function (value) {
    Inertia.get('admin/companies',{
        search:value
    }, {preserveState:true, replace:true});
}, 300))

</script>

<style scoped>

</style>
