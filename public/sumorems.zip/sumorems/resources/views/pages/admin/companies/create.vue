<template>
    <admin>
        <Head>
            <title>Create A Company</title>
        </Head>

        <div class="px-2 py-5">
            <h1 class="font-bold text-xl mt-5 mb-2 text-sumo-300">Create a Company File</h1>
            <hr class="mb-5">
           <form class="pt-5 px-8 pb-5" @submit.prevent="(form.post('/admin/companies'))">
               <h6 class="text-sumo-300 font-bold mb-5 text-lg">Company details</h6>
               <div class=" grid grid-cols-2 gap-3 mt-3">
                   <div>
                       <label class="sumo-label" for="company_name">Company Name:</label>
                       <input type="text" v-model="form.name" class="sumo-input" placeholder="Company Name" id="company_name" required>
                       <div v-if="form.errors.name" class="mt-3 text-red-800 text-sm">
                           <span class="text-xs">{{ form.errors.name}}</span>
                       </div>
                   </div>
                   <div>
                       <label class="sumo-label" for="manager_id">Manager ID:</label>
                       <input type="text" v-model="form.manager_id" class="sumo-input" placeholder="Manager Id e.g XDFEW5" id="manager_id" required>
                       <div v-if="form.errors.manager_id" class="mt-3 text-red-800 text-sm">
                           <span class="text-xs">{{ form.errors.manager_id}}</span>
                       </div>
                   </div>
               </div>
               <div class=" grid grid-cols-2 gap-3 mt-5">
                   <div>
                       <label class="sumo-label" for="company_email">Company Email:</label>
                       <input type="text" v-model="form.email" class="sumo-input" placeholder="Enter company email" id="company_email" required>
                       <div v-if="form.errors.email" class="mt-3 text-red-800 text-sm">
                           <span class="text-xs">{{ form.errors.email}}</span>
                       </div>
                   </div>
                   <div>
                       <label class="sumo-label" for="manager_cellphone">Company Cellphone:</label>
                       <input type="text" v-model="form.cellphone" class="sumo-input" placeholder="Enter company cellphone" id="manager_cellphone" required>
                       <div v-if="form.errors.cellphone" class="mt-3 text-red-800 text-sm">
                           <span class="text-xs">{{ form.errors.cellphone}}</span>
                       </div>
                   </div>
               </div>
               <div class="mt-5">
                   <label class="sumo-label"  for="company_contact_person">Contact Person Name:</label>
                   <input type="text" v-model="form.contact_person" class="sumo-input" placeholder="Enter contact person name" id="company_contact_person" required>
                   <div v-if="form.errors.contact_person" class="mt-3 text-red-800 text-sm">
                       <span class="text-xs">{{ form.errors.contact_person}}</span>
                   </div>
               </div>
               <div class="mt-5">
                   <div>
                       <label class="sumo-label" for="company_logo">Company Logo:</label>
                      <div>
                          <small class="font-medium">Accepted file types PNG, JPG, JPEG. Maximum size of 2MB</small>
                      </div>
                   </div>
                   <input type="file" @input="form.logo=$event.target.files[0]" class="mt-4"  id="company_logo" required>
                   <div v-if="form.errors.logo" class="mt-3 text-red-800 text-sm">
                       <span class="text-xs">{{ form.errors.logo}}</span>
                   </div>
               </div>
              <div class="mb-5 mt-9">
                  <hr>
                  <h6 class="text-sumo-300 font-bold mt-5 text-lg">Company Location</h6>
              </div>

               <div class=" grid grid-cols-2 gap-3 mt-3">
                   <div>
                       <label class="sumo-label" for="company_name">Select Country:</label>
                       <select  class="sumo-input" v-model="form.country_id" required>
                           <option selected value="">Select Country</option>
                           <option v-for="country in countries" :value="country.id" :key="country.id">
                               {{ country.name}}
                           </option>
                       </select>
                       <div v-if="form.errors.country_id" class="mt-3 text-red-800 text-sm">
                           <span class="text-xs">{{ form.errors.country_id}}</span>
                       </div>
                   </div>
                   <div>
                       <label class="sumo-label" for="company_city">Town/City:</label>
                       <input type="text" v-model="form.city" class="sumo-input" placeholder="Enter Company town/city e.g. Nairobi" id="company_city" required>
                   </div>
               </div>
               <div class="mt-5">
                   <label class="sumo-label" for="company_address">Street Address:</label>
                   <input type="text" v-model="form.street_address" class="sumo-input" placeholder="e.g. 124 Mushroom Rd." id="company_address" required>
               </div>
               <div class="flex mt-8 justify-end">
                   <button type="submit" class="btn-primary">Create Company <span class="ml-3"><i class="fal fa-long-arrow-right"></i></span></button>
               </div>
           </form>
        </div>
    </admin>

</template>

<script setup lang="ts">

import Admin from "@/views/layouts/admin.vue";
import {Head} from "@inertiajs/inertia-vue3";
import {useForm} from "@inertiajs/inertia-vue3";

defineProps({
    countries:Object,
})

let form=useForm({
    name:'',
    manager_id:'',
    email:'',
    cellphone:'',
    contact_person:'',
    logo:'',
    country_id:'',
    city:'',
    street_address:''

})

</script>

<style scoped>

</style>
