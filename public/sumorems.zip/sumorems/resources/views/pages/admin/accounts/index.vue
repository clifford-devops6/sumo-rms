<template>
<admin>
    <Head>
        <title>Accounts</title>

    </Head>
    <admin-navbar>
        <template #header> Account types</template>
    </admin-navbar>
    <div class="py-20">
        <div class="bg-sky-50 p-5 flex justify-between ">
            <p>
                <span class="text-sky-800 mr-3"><i class="fas fa-info-circle"></i></span>
                All Account types and classifications. All bills will belong to an account type
            </p>

        </div>

        <!--Accounts table-->
        <div class="border">
            <!--table search and name-->
            <div class="flex justify-between px-3 py-3">
                <div>
                    <h6 class="font-bold">Accounts ({{ accounts.total}})</h6>

                </div>

                <div class=" mr-5">

                    <div class="relative">
                        <div class="flex absolute inset-y-0 left-0 items-center pl-3 pointer-events-none">
                            <svg aria-hidden="true" class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none"
                                 stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                            </svg>
                        </div>
                        <input v-model="search" type="search" id="default-search"
                               class="block p-3 pl-10 w-full text-sm text-gray-900 bg-white rounded-lg border border-gray-300 focus:ring-sky-600 focus:border-sky-600"
                               placeholder="Search roles..." required>

                    </div>
                </div>
            </div>

            <table class="table-auto w-full mt-3 border-t">
                <thead>
                <tr class="bg-gray-100 h-14 text-sky-800">
                    <th class="text-start py-3 px-4">Id</th>
                    <th class="text-start py-3 px-4">Name</th>
                    <th class="text-start py-3 px-4">Created on</th>
                    <th class="text-end py-3 px-4">Action</th>


                </tr>
                </thead>
                <tbody>
                <tr class="border-b" v-if="accounts.data" v-for="account in accounts.data" :key="account.id">
                    <td class="py-3 px-4">{{account.id }}</td>
                    <td class="py-3 px-4">{{account.name }}</td>
                    <td class="py-3 px-4">{{(new Date(account.created_at).toDateString())}}</td>

                    <td class="py-3 px-4">
                        <button type="button" @click="updateUser(account)" class="text-sumo-700 font-medium"><span class="mr-2"><i class="fal fa-pen"></i></span>Edit</button>
                    </td>

                </tr>



                </tbody>

            </table>
            <div class="bg-gray-100 p-3 flex justify-between">
                <div class="self-center">
                    <h6 class="font-medium">Showing <span class="text-sky-800">{{ accounts.current_page }}</span> of
                        <span
                            class="text-sky-800">{{ accounts.last_page }}</span> Page(s)</h6>
                </div>
                <div class="flex" >
                    <Link :href="accounts.prev_page_url" class="btn-primary text-xs m-1"
                          v-if="accounts.prev_page_url" ><span
                        class="mr-2"><i class="far fa-angle-left"></i></span>Prev
                    </Link>
                    <Link :href="accounts.next_page_url" class="btn-primary text-xs m-1" v-if="accounts.next_page_url">
                        Next
                        <span class="ml-2"><i class="far fa-angle-right"></i></span></Link>

                </div>

            </div>
        </div>

    </div>

    <template #sidebar>
        <div class="mt-3">
            <button type="button" @click="createAccount" class="font-bold text-sumo-300"><span class="mr-2"><i class="fal fa-angle-right"></i></span>Add Account</button>
        </div>
    </template>

    <modal :show="showModal" @close="showModal=false" >
        <template #header>
            <h6 class="font-medium text-xl text-sumo-300" v-if="editing">Update Account</h6>
            <h6 class="font-medium text-xl text-sumo-300" v-else>Create Account</h6>
        </template>
        <template #default>
            <form @submit.prevent="handleForm">
                <div class="mt-3">
                    <label for="account-name" class="sumo-label">Account Name:</label>
                    <input type="text" class="sumo-input" id="account-name"
                           placeholder="Enter account name"
                           required v-model="form.name" />
                    <div v-if="form.errors.name" class="mt-3 text-red-800 text-sm">
                                    <span>
                                        <span class="mr-2"><i class="fal fa-exclamation-circle"></i></span>
                                        {{form.errors.name}}
                                    </span>
                    </div>
                </div>
                <div class="py-3 flex justify-end mt-3">
                 <button type="submit" class="btn-primary" v-if="editing">Update Account</button>
                    <button type="submit" class="btn-primary" v-else>Create Account</button>
                </div>

            </form>
        </template>
    </modal>
</admin>
</template>

<script setup lang="ts">
import Admin from "@/views/layouts/admin.vue"
import AdminNavbar from "@/views/components/admin-navbar.vue";
import {Head, useForm} from "@inertiajs/inertia-vue3";
import {Link} from "@inertiajs/inertia-vue3";
import Swal from "sweetalert2";
import {ref, watch} from "vue";
import {Inertia} from "@inertiajs/inertia";
import Modal from "@/views/components/modal.vue";
import _ from "lodash"
let props=defineProps({
    status:String,
    accounts:Object,
    filters:Object
})
let form=useForm({
    name:'',
    _method:'',
    id:''
})
let showModal=ref(false)
let editing=ref(false)
let createAccount=()=>{
    editing.value=false
    showModal.value=true
    form.reset()
}
const updateUser=(account)=>{
    showModal.value=true
    editing.value=true
    form.name=account.name
    form._method='patch'
    form.id=account.id

}


let search=ref(props.filters.search)
watch(search, _.debounce(function (value) {
    Inertia.get('/admin/accounts',{
        search:value
    }, {preserveState:true, replace:true});
}, 300))

let submit=()=>{
     form.post('/admin/accounts',{
         onSuccess:()=>{
             form.reset()
             showModal.value=false
             Swal.fire({
                 position: 'top-end',
                 text: props.status,
                 showConfirmButton: false,
                 timer: 3000,
                 backdrop:false
             })
         }
     })
}
let update=()=>{
    form.post('/admin/accounts/'+form.id,{
        onSuccess:()=>{
            form.reset()
            showModal.value=false
            Swal.fire({
                position: 'top-end',
                text: props.status,
                showConfirmButton: false,
                timer: 3000,
                backdrop:false
            })
        }
    })
}

let  handleForm=(account)=>{
    if (editing.value){
        update(account);
    }else {
        submit();
    }
}
</script>

<style scoped>

</style>
