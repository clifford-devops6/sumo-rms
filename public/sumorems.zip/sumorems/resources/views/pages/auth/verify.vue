<template layout>
    <Head>
        <title>Register</title>
    </Head>
    <div class="grid h-screen bg-sumo-300 grid-cols-2">
        <div class="flex justify-center">
            <div class="self-center text-white w-96 px-5">
                <h1 class="font-bold text-4xl">Create an Account</h1>
                <p class="text-xs mt-4">We provide Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                <div class="mt-7">
                    <div class="flex">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-usd-circle"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">Absolutely FREE</h6>
                            <p class="text-sm mt-2 text-gray-300">No hidden chargers. No credit card required</p>
                        </div>
                    </div>
                    <div class="flex mt-5">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-poo-storm"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">First & Easy</h6>
                            <p class="text-sm mt-2 text-gray-300">No hidden chargers. No credit card required</p>
                        </div>
                    </div>
                    <div class="flex mt-5">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-clipboard-user"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">Your own Data</h6>
                            <p class="text-sm mt-2 text-gray-300">Enjoy free trial with your company data</p>
                        </div>
                    </div>

                    <div class="flex mt-5">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="far fa-medal"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">Unlimited Resources</h6>
                            <p class="text-sm mt-2 text-gray-300">Access all the features of the world's #1 POS Software!</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-l-3xl flex justify-center">
            <div class="self-center w-3/5 px-5">
                <div class="py-3 place-content-center">
                    <img :src="'/images/final-logo-outlines.png'" class="w-96 mb-5">
                </div>
                <div class="mt-32">
                    <div class=" py-5 px-5">
                        <div class="bg-sky-50 p-3 flex rounded-md"  v-if="$page.props.status">
                            <div class="mr-3">
                                <span class="text-sky-800"><i class="fas fa-info-circle"></i></span>
                            </div>
                            <div >
                                <p class="text-sky-800 text-sm">{{$page.props.status}}</p>
                            </div>

                        </div>
                        <p class="mt-3 text-sm text-center">Before proceeding, please check your email for a verification OTP code.</p>
                    </div>
                    <form @submit.prevent="form.post('/auth/verified')">
                        <div class="mt-7 px-5">

                            <input type="text" class="sumo-input text-center" id="otp-code" placeholder="Enter 6 digit OTP Code" required v-model="form.otp_code"/>
                            <div v-if="form.errors.otp_code" class="mt-3 text-red-800 text-sm">
                                <span><span class="mr-2"><i class="fal fa-exclamation-circle"></i></span>{{ form.errors.otp_code}}</span>
                            </div>
                        </div>
                        <div class="py-5 px-3 flex justify-center gap-2">
                            <div>
                                <Link href="/auth/resend-link"
                                      method="post" as="button" class="btn-primary">
                                    Resend OTP
                                </Link>

                            </div>
                            <div>
                                <button type="submit" class="btn-success">Verify</button>
                            </div>

                        </div>
                    </form>

                </div>
            </div>


        </div>
    </div>
</template>

<script setup lang="ts">
import {Head} from "@inertiajs/inertia-vue3";
import {Link} from "@inertiajs/inertia-vue3";
import {useForm} from "@inertiajs/inertia-vue3";

let form=useForm({
    otp_code:''
})


</script>

