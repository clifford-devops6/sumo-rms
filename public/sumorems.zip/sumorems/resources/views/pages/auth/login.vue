<template layout>
    <Head>
        <title>Login</title>
    </Head>
    <div class="grid h-screen bg-sumo-300 grid-cols-2">
        <div class="flex justify-center">
            <div class="self-center text-white w-96 px-5">
                <h1 class="font-bold text-4xl">Create an Account</h1>
                <p class="text-xs mt-4">We provide Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                <div class="mt-7">
                    <div class="flex">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-usd-circle"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">Absolutely FREE</h6>
                            <p class="text-sm mt-2 text-gray-300">No hidden chargers. No credit card required</p>
                        </div>
                    </div>
                    <div class="flex mt-5">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-poo-storm"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">First & Easy</h6>
                            <p class="text-sm mt-2 text-gray-300">No hidden chargers. No credit card required</p>
                        </div>
                    </div>
                    <div class="flex mt-5">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-clipboard-user"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">Your own Data</h6>
                            <p class="text-sm mt-2 text-gray-300">Enjoy free trial with your company data</p>
                        </div>
                    </div>

                    <div class="flex mt-5">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="far fa-medal"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">Unlimited Resources</h6>
                            <p class="text-sm mt-2 text-gray-300">Access all the features of the world's #1 POS Software!</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-l-3xl flex justify-center">
            <div class="self-center w-3/5 px-5">
                <div class="py-3 place-content-center">
                    <img :src="'/images/final-logo-outlines.png'" class="w-96 mb-5">
                </div>
                <div>
                    <form @submit.prevent="form.post('/auth/authenticate')">

                        <div class="mt-7">
                            <input type="email" class="sumo-input" id="form-input" placeholder="Enter your email" required v-model="form.email"/>
                            <div v-if="form.errors.email" class="mt-3 text-red-800 text-sm">
                                <span class="text-xs">{{ form.errors.email }}</span>
                            </div>
                        </div>
                        <div class="mt-8">

                            <input type="password" class="sumo-input" id="password" placeholder="Enter your password" required v-model="form.password"/>
                            <div v-if="form.errors.password" class="mt-3 text-red-800 text-sm">
                                <span class="text-xs">{{ form.errors.password}}</span>
                            </div>
                        </div>

                        <div class="flex mt-5 justify-between">
                            <Link href="/auth/password-reset" title="Password Reset" class="hover:text-sky-800 self-center">Forgot password?</Link>
                            <button type="submit" class="btn-primary  m-1" :disabled="form.processing">Login</button>
                        </div>

                        <div class="flex mt-8 justify-center">
                            <div class="w-full">
                                <div class="flex justify-between">
                                    <hr class="w-36 self-center">
                                    <p class="self-center">or</p>
                                    <hr class="w-36 self-center">
                                </div>
                                <p class="font-medium text-center mt-3">
                                    Don't have a RemsGlobal account?<br>
                                    <Link :href="route('register')" title="Register" class="text-sumo-700">Create an account</Link>
                                </p>
                            </div>

                        </div>
                    </form>

                </div>
            </div>


        </div>
    </div>
</template>

<script setup lang="ts">
import {Head} from "@inertiajs/inertia-vue3";
import {Link} from "@inertiajs/inertia-vue3";
import {ref} from "vue";
import {useForm} from "@inertiajs/inertia-vue3";
import {Inertia} from "@inertiajs/inertia";


let form=useForm({
    'email':'',
    'password':'',



})




</script>

<style scoped>

</style>
