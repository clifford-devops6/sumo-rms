<template layout>
<Head>
    <title>Register</title>
</Head>
    <div class="grid h-screen bg-sumo-300 grid-cols-2">
     <div class="flex justify-center">
        <div class="self-center text-white w-96 px-5">
            <h1 class="font-bold text-4xl">Create an Account</h1>
            <p class="text-xs mt-4">We provide Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
        <div class="mt-7">
            <div class="flex">
                <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-usd-circle"></i></span></div>
                <div>
                    <h6 class="font-semibold text-sm">Absolutely FREE</h6>
                    <p class="text-sm mt-2 text-gray-300">No hidden chargers. No credit card required</p>
                </div>
            </div>
            <div class="flex mt-5">
                <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-poo-storm"></i></span></div>
                <div>
                    <h6 class="font-semibold text-sm">First & Easy</h6>
                    <p class="text-sm mt-2 text-gray-300">No hidden chargers. No credit card required</p>
                </div>
            </div>
            <div class="flex mt-5">
                <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-clipboard-user"></i></span></div>
                <div>
                    <h6 class="font-semibold text-sm">Your own Data</h6>
                    <p class="text-sm mt-2 text-gray-300">Enjoy free trial with your company data</p>
                </div>
            </div>

            <div class="flex mt-5">
                <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="far fa-medal"></i></span></div>
                <div>
                    <h6 class="font-semibold text-sm">Unlimited Resources</h6>
                    <p class="text-sm mt-2 text-gray-300">Access all the features of the world's #1 POS Software!</p>
                </div>
            </div>
        </div>
        </div>
     </div>
        <div class="bg-white rounded-l-3xl flex justify-center">
            <div class="self-center w-3/5 px-5">
                <div class="py-3 place-content-center">
                    <img :src="'/images/final-logo-outlines.png'" class="w-96 mb-5">
                </div>
                <div>
                    <form autocomplete="off"  @submit.prevent="submit">
                        <div v-if="formStep==1">
                            <div class="relative w-full">
                                <input type="email"  class="sumo-input" placeholder="Email Address" v-model="form.email">
                                <div v-if="errors.email" class="mt-3 text-red-800 text-sm">
                                    <span class="text-xs">{{errors.email }}</span>
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-2 mt-6">
                                <div class="relative w-full">
                                    <input type="text"  class="sumo-input" placeholder="First Name" v-model="form.name">
                                    <div v-if="errors.name" class="mt-3 text-red-800 text-sm">
                                        <span class="text-xs">{{errors.name }}</span>
                                    </div>
                                </div>
                                <div class="relative w-full">
                                    <input type="text"  class="sumo-input" placeholder="Last Name" v-model="form.last_name">
                                    <div v-if="errors.last_name" class="mt-3 text-red-800 text-sm">
                                        <span class="text-xs">{{errors.last_name }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-6">
                                <div class="grid grid-cols-6">
                                    <div class="col-span-2 z-50">
                                        <div class="relative w-full">
                                                <button type="button" class="border border-gray-300 block z-1000 h-12 w-full
                                                overflow-hidden p-2 text-start rounded-l-xl"
                                                        @click="show=!show">
                                                    <p class="w-full"> <span :class="'fi fi-'+form.country.code+' rounded-sm mr-1' "></span> <span class="capitalize font-bold">{{form.country.name}}</span><span class="ml-2 float-right"><i class="fas fa-caret-down"></i></span></p>
                                                </button>

                                                <Transition
                                                    enter-active-class="transition ease-out duration-100"
                                                    enter-class="transform opacity-0 scale-95"
                                                    enter-to-class="transform opacity-100 scale-100"
                                                    leave-active-class="transition ease-in duration-75"
                                                    leave-class="transform opacity-100 scale-100"
                                                    leave-to-class="transform opacity-0 scale-95"
                                                >
                                                    <div  class="shadow-md border absolute rounded-md w-full  divide-y z-1000 bg-white" v-if="show">
                                                        <div class="w-full flex" v-for="country in countries" :key="country.id">
                                                            <label class="cursor-pointer w-full px-2 py-3 text-sm hover:bg-gray-100" :for="country.id" >
                                                                <input type="radio" class="hidden" v-model="form.country" :value="country" :id="country.id">
                                                                <span :class="'fi fi-'+country.code+' rounded-sm mr-2' "></span> <span class="font-bold capitalize">{{country.name}}</span>
                                                            </label>

                                                        </div>



                                                    </div>
                                                </Transition>
                                            </div>
                                    </div>

                                    <div class="relative w-full col-span-4">
                                        <input type="tel" v-model="form.cellphone"  class=" rounded-xl rounded-l-none w-full
                                    text-sm border bg-gray-50 border border-l-0 border-gray-300 text-gray-900 focus:ring-sky-600 focus:border-sky-600 block h-12 p-2" placeholder="Cellphone">
                                    </div>

                                </div>
                                <div class="flex justify-between">

                                    <div v-if="errors.country_id" class="mt-3 text-red-800 text-sm">
                                        <span class="text-xs">{{errors.country_id }}</span>
                                    </div>
                                    <div v-if="errors.cellphone" class="mt-3 text-red-800 text-sm">
                                        <span class="text-xs">{{errors.cellphone }}</span>
                                    </div>
                                </div>
                                <p class="mt-2 text-xs">Standard call, messaging or data rates may apply</p>
                            </div>

                            <div class="relative w-full mt-6">
                                <input type="password" v-model="form.password"  class="sumo-input" placeholder="Password" autocomplete="new-password">
                                <div v-if="errors.password" class="mt-3 text-red-800 text-sm">
                                    <span class="text-xs">{{errors.password}}</span>
                                </div>
                            </div>
                            <div class="flex items-center mt-4">
                                <input id="terms" type="checkbox" required v-model="form.terms" value="1" class="w-4 h-4 text-green-600 bg-gray-100 rounded border-gray-300 focus:ring-green-600 dark:focus:ring-green-600  focus:ring-2">
                                <label for="terms" class="ml-2 text-sm font-medium text-gray-900 dark:text-gray-300">
                                    By clicking start free trial I agree  that I have read and accepted the
                                    Terms of use and Privacy Policy
                                </label>
                            </div>
                            <div v-if="errors.terms" class="mt-3 text-red-800 text-sm">
                                <span class="text-xs">{{errors.terms}}</span>
                            </div>
                        </div>
                        <div class="mt-3" v-if="formStep==2">
                            <h6 class="text-sumo-700 font-medium mb-2">Profile Setup</h6>
                            <hr>
                            <p class="mt-5 font-medium">I am a</p>
                            <div class="mt-3">
                                <div v-if="errors.role_id" class="mt-3 text-red-800 text-sm">
                                    <span class="text-xs">{{errors.role_id}}</span>
                                </div>
                                <div class="mt-2 divide-y">

                                    <div class="py-2" v-for="role in roles">
                                        <label :for="'role'+role.id" class="flex" :key="role.id">
                                            <input :id="'role'+role.id" type="radio" :value="role.id" class="hidden peer" required v-model="form.role_id" name="role_id">
                                            <div class="ml-2 text-sm font-medium text-gray-900  peer-checked:bg-sumo-500 rounded-lg py-3 px-3 w-full cursor-pointer  peer-checked:bg-opacity-25">
                                                {{role.name}}
                                            </div>
                                        </label>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="mt-7" v-if="formStep==1">
                            <button type="button" class="btn-primary w-full" @click="formValidate">Start Free Trial</button>
                            <div class="mt-6 text-center">
                                <h3 class="font-medium">Already have a RemsGlobal account?</h3>
                                <Link :href="route('login')" class="text-sumo-700 font-medium">Sign in</Link>
                            </div>
                        </div>
                        <div class="mt-7" v-if="formStep==2">
                            <p class="py-2 font-medium text-sumo-800">You may set up one profile at a time</p>
                            <div class="mt-6 flex justify-between">
                                <button type="button" class="btn-link" @click="formStep--"><span class="mr-2"><i class="fal fa-angle-left"></i></span>Back</button>
                                <button type="submit" class="btn-primary">Next <span class="ml-2"><i class="fal fa-angle-right"></i></span></button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>


        </div>
    </div>
</template>

<script setup lang="ts">
import {Head} from "@inertiajs/inertia-vue3";
import {Link} from "@inertiajs/inertia-vue3";
import {ref, watch} from "vue";
import {useForm} from "@inertiajs/inertia-vue3";
import {Inertia} from "@inertiajs/inertia";
let props=defineProps({
    countries:Object,
    roles:Object,
    errors:Object,
    default_country:Object,
})

let form=useForm({
    'role_id':'',
    'email':'',
    'name':'',
    'last_name':'',
    'cellphone':'',
    'country':props.default_country,
    'password':'',
    'terms':'',


})

let formStep=ref(1)
let formValidate=()=>{

    Inertia.post('/register/stepOne',{
     name:form.name, last_name:form.last_name,
        email:form.email, cellphone:form.cellphone,
        country_id:form.country.id, terms:form.terms,
        password:form.password
    },{
        onSuccess:()=>{
            formStep.value++
        }
    })
}
let submit=()=>{
    form.post('/auth/create',{
        onSuccess:()=>{
            formStep.value--
        }
    })
}

const show=ref(false)
watch(form,()=>{
    show.value=false
})

</script>

<style scoped>

</style>
