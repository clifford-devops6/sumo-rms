<template layout>
    <Head>
        <title>Reset Password</title>
    </Head>
    <div class="grid h-screen bg-sumo-300 grid-cols-2">
        <div class="flex justify-center">
            <div class="self-center text-white w-96 px-5">
                <h1 class="font-bold text-4xl">Create an Account</h1>
                <p class="text-xs mt-4">We provide Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                <div class="mt-7">
                    <div class="flex">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-usd-circle"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">Absolutely FREE</h6>
                            <p class="text-sm mt-2 text-gray-300">No hidden chargers. No credit card required</p>
                        </div>
                    </div>
                    <div class="flex mt-5">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-poo-storm"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">First & Easy</h6>
                            <p class="text-sm mt-2 text-gray-300">No hidden chargers. No credit card required</p>
                        </div>
                    </div>
                    <div class="flex mt-5">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="fas fa-clipboard-user"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">Your own Data</h6>
                            <p class="text-sm mt-2 text-gray-300">Enjoy free trial with your company data</p>
                        </div>
                    </div>

                    <div class="flex mt-5">
                        <div class="mr-4"><span class="text-yellow-500 text-lg"><i class="far fa-medal"></i></span></div>
                        <div>
                            <h6 class="font-semibold text-sm">Unlimited Resources</h6>
                            <p class="text-sm mt-2 text-gray-300">Access all the features of the world's #1 POS Software!</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-l-3xl flex justify-center">
            <div class="self-center w-3/5 px-5">
                <div class="py-3 place-content-center">
                    <img :src="'/images/final-logo-outlines.png'" class="w-96 mb-5">
                </div>
                <div class="mt-24">
                    <h6 class="text-center mb-8">Forgot Password</h6>
                    <form @submit.prevent=" form.post('/auth/password-store');">

                        <div class="mt-3">

                            <input type="email" class="sumo-input text-center" id="form-input" placeholder="Enter your email" required v-model="form.email"/>
                            <div v-if="form.errors.email" class="mt-3 text-red-800 text-center text-xs">
                                <span >{{ form.errors.email }}</span>
                            </div>
                        </div>

                        <div class="flex mt-4 justify-center">
                            <button type="submit" class="btn-primary  m-1">Send reset link</button>
                        </div>
                        <div v-if="$page.props.status" class="text-center text-green-800 font-medium mt-5">
                            <span>{{ $page.props.status }}</span>
                        </div>

                    </form>
                </div>
            </div>


        </div>
    </div>
</template>

<script setup lang="ts">
import {Head} from "@inertiajs/inertia-vue3";
import {useForm} from "@inertiajs/inertia-vue3";


let form=useForm({
    'email':''
})






</script>

<style scoped>

</style>
