<template layout="manager">
    <Head>
        <title>Manager</title>
        <meta head-key="description" name="description" content="This is the default description" />

    </Head>
    <div>
      <manager-navbar>
          <template #header>
              Manager Panel
          </template>
          <template #links>

          </template>
      </manager-navbar>
    </div>
    <div class="mt-24">
        <div class="px-7 mt-5 mb-3">
            <h1 class="text-2xl text-gray-400">Master Dashboard</h1>
        </div>
        <hr class="mx-7 h-px bg-gray-200 border-0">
        <!--cards-->
        <div class="mt-5 px-5  grid grid-cols-4 gap-2">
            <div class="bg-gray-100 shadow-md h-48 overflow-hidden">
                <div class="border-b py-5 px-5">
                    <h1 class="font-semibold text-xl">This will be the card title</h1>
                </div>
                <div class="py-5 px-5">
                    <div>
                        <h6 class="font-semibold text-xl">Card title will be here</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the .</p>
                    </div>
                </div>
            </div>
            <div class="bg-gray-100 shadow-md h-48 overflow-hidden">
                <div class="border-b py-5 px-5">
                    <h1 class="font-semibold text-xl">This will be the card title</h1>
                </div>
                <div class="py-5 px-5">
                    <div>
                        <h6 class="font-semibold text-xl">Card title will be here</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the .</p>
                    </div>
                </div>
            </div>
            <div class="bg-gray-100 shadow-md h-48 overflow-hidden">
                <div class="border-b py-5 px-5">
                    <h1 class="font-semibold text-xl">This will be the card title</h1>
                </div>
                <div class="py-5 px-5">
                    <div>
                        <h6 class="font-semibold text-xl">Card title will be here</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the .</p>
                    </div>
                </div>
            </div>
            <div class="bg-gray-100 shadow-md h-48 overflow-hidden">
                <div class="border-b py-5 px-5">
                    <h1 class="font-semibold text-xl">This will be the card title</h1>
                </div>
                <div class="py-5 px-5">
                    <div>
                        <h6 class="font-semibold text-xl">Card title will be here</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the .</p>
                    </div>
                </div>
            </div>
            <div class="bg-gray-100 shadow-md h-48 overflow-hidden">
                <div class="border-b py-5 px-5">
                    <h1 class="font-semibold text-xl">This will be the card title</h1>
                </div>
                <div class="py-5 px-5">
                    <div>
                        <h6 class="font-semibold text-xl">Card title will be here</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the .</p>
                    </div>
                </div>
            </div>
            <div class="bg-gray-100 shadow-md h-48 overflow-hidden">
                <div class="border-b py-5 px-5">
                    <h1 class="font-semibold text-xl">This will be the card title</h1>
                </div>
                <div class="py-5 px-5">
                    <div>
                        <h6 class="font-semibold text-xl">Card title will be here</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the .</p>
                    </div>
                </div>
            </div>
            <div class="bg-gray-100 shadow-md h-48 overflow-hidden">
                <div class="border-b py-5 px-5">
                    <h1 class="font-semibold text-xl">This will be the card title</h1>
                </div>
                <div class="py-5 px-5">
                    <div>
                        <h6 class="font-semibold text-xl">Card title will be here</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the .</p>
                    </div>
                </div>
            </div>
            <div class="bg-gray-100 shadow-md h-48 overflow-hidden">
                <div class="border-b py-5 px-5">
                    <h1 class="font-semibold text-xl">This will be the card title</h1>
                </div>
                <div class="py-5 px-5">
                    <div>
                        <h6 class="font-semibold text-xl">Card title will be here</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the .</p>
                    </div>
                </div>
            </div>
            <div class="bg-gray-100 shadow-md h-48 overflow-hidden">
                <div class="border-b py-5 px-5">
                    <h1 class="font-semibold text-xl">This will be the card title</h1>
                </div>
                <div class="py-5 px-5">
                    <div>
                        <h6 class="font-semibold text-xl">Card title will be here</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the .</p>
                    </div>
                </div>
            </div>
            <div class="bg-gray-100 shadow-md h-48 overflow-hidden">
                <div class="border-b py-5 px-5">
                    <h1 class="font-semibold text-xl">This will be the card title</h1>
                </div>
                <div class="py-5 px-5">
                    <div>
                        <h6 class="font-semibold text-xl">Card title will be here</h6>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                            Lorem Ipsum has been the .</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { Head } from '@inertiajs/inertia-vue3'
import Editor from "@tinymce/tinymce-vue";
import {Dropdown} from "flowbite-vue";
import ManagerNavbar from "@/views/components/manager-navbar.vue";

defineProps({
    user:Object,
})

</script>

