export function useTruncate(){




}
