<?php



use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\AuthenticatedUser;
use App\Http\Controllers\PasswordResetController;



//Authentication routes
Route::group(['middleware'=>['guest']], function(){
    Route::get('/auth/register',[AuthController::class, 'register'])->name('register');
    Route::get('/auth/login',[AuthController::class, 'login'])->name('login');
    Route::post('auth/authenticate',[AuthController::class, 'authenticate']);
    Route::post('/register/stepOne',[AuthController::class,'stepOne']);//validate form step one
    Route::post('/auth/create',[AuthController::class, 'create']);
    Route::get('/auth/password-reset',[PasswordResetController::class, 'reset'])->name('password-link');
    Route::post('/auth/password-store',[PasswordResetController::class, 'store']);
    Route::get('/auth/reset-password/{token}', [PasswordResetController::class, 'create'])->name('password.reset');
    Route::post('/auth/update-password', [PasswordResetController::class, 'update']);


});

Route::group(['middleware'=>['auth']], function (){
    //logout landlord
    Route::post('/auth/logout',[AuthenticatedUser::class, 'destroy']);
    Route::get('/auth/verify',[AuthenticatedUser::class, 'verify'])->name('verify');
    Route::post('/auth/verified',[AuthenticatedUser::class, 'checkVerification'])->name('verified');
    Route::post('/auth/resend-link',[AuthenticatedUser::class, 'resendVerification'])->middleware('throttle:6,1');
});


