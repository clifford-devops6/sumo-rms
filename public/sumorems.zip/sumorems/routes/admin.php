<?php
use Illuminate\Support\Facades\Route;
/*
 * Super Admin routes goes to this section
*/
use  App\Http\Controllers\Admin\AdminController;
use  App\Http\Controllers\Admin\AdminProfileController;
use App\Http\Controllers\Admin\AdminRoleController;
use App\Http\Controllers\Admin\AdminPermissionController;
use App\Http\Controllers\admin\AdminUsersController;
use App\Http\Controllers\Admin\AdminManagersController;
use App\Http\Controllers\Admin\AdminCaretakersController;
use App\Http\Controllers\Admin\AdminTenantsController;
use App\Http\Controllers\Admin\AdminLandlordController;
use App\Http\Controllers\Admin\AdminLogsController;
use App\Http\Controllers\Admin\AdminCompaniesController;
use App\Http\Controllers\Admin\AdminAccountsController;


Route::group(['middleware'=>['auth','verified','role:Super-Admin']],function (){
    Route::resource('/admin/accounts',AdminAccountsController::class);
    Route::resource('/admin/companies',AdminCompaniesController::class);
    Route::patch('/admin/profile/password/{id}',[AdminProfileController::class, 'change'])->name('change-password');
    Route::resource('/admin/profile/settings',AdminProfileController::class);
    Route::resource('/admin/roles-and-permissions/roles',AdminRoleController::class);
    Route::resource('/admin/roles-and-permissions/permission',AdminPermissionController::class);

    //Users Controller

    Route::resource('/admin/users/managers',AdminManagersController::class);
    Route::resource('/admin/users/caretakers',AdminCaretakersController::class);
    Route::resource('/admin/users/admins',AdminUsersController::class);
    Route::resource('/admin/users/tenants',AdminTenantsController::class);
    Route::resource('/admin/users/landlords',AdminLandlordController::class);

    Route::resource('admin/activity-logs', AdminLogsController::class);
    Route::resource('/admin',AdminController::class);

});
