<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Tenant\TenantController;
//tenant routes

Route::group(['middleware'=>['auth','role:Tenant','verified']], function (){
    Route::resource('/tenant', TenantController::class);
});
