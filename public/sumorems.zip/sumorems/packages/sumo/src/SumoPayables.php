<?php
namespace Nyawach\Sumo;

class SumoPayables{

}
