<?php
namespace Nyawach\Sumo;

class SumoReceivables{

}

