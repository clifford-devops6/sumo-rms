<?php
namespace  Nyawach\Sumo;
use Illuminate\Support\ServiceProvider;
use Nyawach\Sumo\Facades\Entity;

class SumoAccountsServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        //

        $this->app->bind('sumo-payable', function () {
            return new SumoPayables();
        });
        $this->app->bind('sumo-receivable', function () {
            return new SumoReceivables();
        });
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
        $this->loadMigrationsFrom(__DIR__.'/database/migrations');

    }
}
