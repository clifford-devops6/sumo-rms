<?php

namespace Nyawach\Sumo\Facades;

use Illuminate\Support\Facades\Facade;

class Recievable extends Facade
{
    public static function getFacadeAccessor()
    {
        return 'sumo-receivable';
    }
}
