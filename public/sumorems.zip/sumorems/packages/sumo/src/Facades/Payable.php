<?php

namespace Nyawach\Sumo\Facades;

use Illuminate\Support\Facades\Facade;

class Payable extends Facade
{
    public static function getFacadeAccessor()
    {
        return 'sumo-payable';
    }
}
