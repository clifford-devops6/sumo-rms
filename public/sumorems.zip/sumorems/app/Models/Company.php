<?php

namespace App\Models;


use Cviebrock\EloquentSluggable\Sluggable;
use Cviebrock\EloquentSluggable\SluggableScopeHelpers;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;


class Company extends Model implements  HasMedia
{
    use HasFactory, InteractsWithMedia, Sluggable, SluggableScopeHelpers;

    /**
     * Return the sluggable configuration array for this model.
     *
     * @return array
     */
    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'name'
            ]
        ];
    }

    protected $fillable=[
        'name', 'cellphone', 'contact_person','user_id','email','slug'
    ];

    public function location(){
        return $this->morphOne(Location::class,'location');
    }


    public function user(){
        return $this->belongsTo(User::class);
    }

    public function payables(){
        return $this->hasMany(Payable::class);
    }

    public function receivables(){
        return $this->hasMany(Receivable::class);
    }

    public function registerMediaConversions(Media $media = null): void
    {
        $this->addMediaConversion('logo-icon')
            ->width(300);

    }






}
