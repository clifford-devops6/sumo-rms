<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Property extends Model
{
    use HasFactory;

    protected $fillable=[
        'name', 'property_code','type_id','company_id','landlord_id','description',
        'property_type_id','portfolio_id'
    ];

    public function location(){
        return $this->morphOne(Location::class,'location');
    }

    public function propertyType(){
        return $this->belongsTo(PropertyType::class);
    }

    public function portfolio(){
        return $this->belongsTo(Portfolio::class);
    }

    public function company(){
        return $this->belongsTo(Company::class);
    }

    public function user(){
        return $this->belongsTo(User::class);
    }


}
