<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bill extends Model
{
    use HasFactory;

    protected $fillable=[
        'company_id','lease_id','amount','due_date','payment_id','billable_type','billable_id',
        'account_id','status'
    ];
}
