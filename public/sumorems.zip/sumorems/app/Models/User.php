<?php

namespace App\Models;

//use Illuminate\Contracts\Auth\MustVerifyEmail;
use App\Notifications\CustomResetPassword;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;




class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'last_name',
        'email_verified',
        'status',
        'cellphone',
        'country_id',
        'terms',
        'user_code'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'email_verified'
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


    public function guests(){
        return $this->hasMany(Guest::class);
    }

    public function appointments(){
        return $this->hasMany(Appointment::class);
    }

    public function company(){
        return $this->hasOne(Company::class);
    }

    public function payer(){
        return $this->hasMany(Payable::class,'payer');
    }

    public function payee(){
        return $this->hasMany(Payable::class,'payee');
    }

    public function receiver(){
        return $this->hasMany(Receivable::class,'receiver');
    }

    public function remitter(){
        return $this->hasMany(Receivable::class,'remitter');
    }



}
