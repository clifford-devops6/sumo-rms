<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CompanyResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return[
            'id'=>$this->id,
            'name'=>$this->name,
            'contact_person'=>$this->contact_person,
            'email'=>$this->email,
            'cellphone'=>$this->cellphone,
            'slug'=>$this->slug,
            'manager'=> new UserResource($this->user),
            'location'=>new LocationResource($this->location),
            'image'=> $this->getFirstMediaUrl('logo','logo-icon')
        ];
    }
}
