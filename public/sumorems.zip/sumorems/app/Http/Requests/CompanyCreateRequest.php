<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CompanyCreateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'name'=>'required|max:255|string',
            'manager_id'=>'required|string|size:6|exists:users,user_code',
            'email'=>'required|email|unique:companies|string|max:255',
            'cellphone'=>'required|string|max:13',
            'country_id'=>'required|integer',
            'contact_person'=>'required|max:255|string',
            'logo'=>'required|image|mimes:jpeg,png,jpg|max:2048',
            'city'=>'required|max:255|string',
            'street_address'=>'required|max:255|string',
        ];
    }

    public function  messages()
    {
        return [
            'manager_id.exists'=>'The manager does not exists in the database',
            'email.unique'=>'A company with similar email already exists',

        ];
    }
}
