<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CompanyUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'name'=>'nullable|max:255|string',
            'manager_id'=>'nullable|string|size:6|exists:users,user_code',
            'email'=>'nullable|email|exists:companies|string|max:255',
            'cellphone'=>'nullable|string|max:13',
            'country_id'=>'nullable|integer',
            'contact_person'=>'nullable|max:255|string',
            'logo'=>'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'city'=>'nullable|max:255|string',
            'street_address'=>'nullable|max:255|string',
        ];
    }
}
