<?php

namespace App\Http\Controllers\Auth;

use App\Events\EmailVerify;
use App\Http\Controllers\Controller;
use App\Models\Verify\VerifyUser;
use App\Providers\RouteServiceProvider;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class AuthenticatedUser extends Controller
{
    //logout user

    public function destroy(Request $request){
        Auth::guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/');
    }

    public function verify(){
        if (Auth::user()->email_verified){
            return  redirect('/');
        }
        return inertia::render('/auth/verify');
    }

    public function resendVerification()
    {
        $verifyUser = VerifyUser::where('user_id', Auth::id())->first();
        $otp = rand(111111,999999);
        $verifyUser = VerifyUser::create([
            'user_id' => Auth::id(),
            'otp_code' => $otp
        ]);
        //event for email verification
        $user=Auth::user();
        $otp=$verifyUser->otp_code;
        EmailVerify::dispatch($user,$otp);

        return redirect()->back()
            ->with('status', 'OTP Sent Successfully');
    }

    //verify email
    public function checkVerification(Request $request){

        $validated=$request->validate([
            'otp_code'=>'required|integer|digits:6'
        ]);
        $verifyUser=VerifyUser::where('otp_code', $validated['otp_code'])->firstOrFail();
        if(!is_null($verifyUser) ){
            if ($verifyUser->created_at>=Carbon::now()->subMinutes(15)){
                $user=$verifyUser->user;
                if(!$user->email_verified) {
                    $verifyUser->user->email_verified = 1;
                    $verifyUser->user->save();
                    $role=Auth::user()->getRoleNames()->first();
                    switch ($role) {
                        case($role=='Super-Admin'):
                            return redirect(RouteServiceProvider::HOME);
                            break;
                        case($role=='Property-manager'):
                            return redirect(RouteServiceProvider::MANAGER);
                            break;
                        case($role=='Landlord'):
                            return redirect(RouteServiceProvider::LANDLORD);
                            break;
                        case($role=='Staff'):
                            return redirect(RouteServiceProvider::STAFF);
                            break;
                        case($role=='Tenant'):
                            return redirect(RouteServiceProvider::TENANT);
                        case($role=='Caretaker'):
                            return redirect(RouteServiceProvider::CARETAKER);
                            break;
                        default:
                            return redirect('/');
                    }
                }else{
                    return redirect('/');
                }
            }else{
                return  redirect('/auth/verify')
                    ->with('status', 'The OTP code entered is expired');
            }
        }else{
            return  redirect('/auth/verify')
                ->with('status', 'We could not find the OTP provided in our database');
        }
    }
}
