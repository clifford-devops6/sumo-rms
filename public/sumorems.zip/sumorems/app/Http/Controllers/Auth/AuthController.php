<?php

namespace App\Http\Controllers\Auth;

use App\Events\EmailVerify;
use App\Http\Controllers\Controller;
use App\Models\Country;
use App\Models\User;
use App\Models\Verify\VerifyUser;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Nyawach\Sumo\Facades\Entity;
use Spatie\Permission\Models\Role;


class AuthController extends Controller
{
    //register user;

    public function register(){

        $countries=Country::select('id','prefix','code','name')->get();
        $roles=Role::where('name','!=','Super-Admin')->select(['id','name'])->get();
        $default_country=Country::where('prefix','=','+254')->select('id','name','code')->firstorFail();

        return inertia::render('register', compact('countries','roles','default_country'));
    }

    public function stepOne(Request $request){
        $validated=$request->validate([
            'name'=>['required', 'string', 'max:255'],
            'last_name'=>['required', 'string', 'max:255'],
            'email'=>['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8'],
            'cellphone'=>['required','max:13','min:9'],
            'terms'=>['required','integer'],
            'country_id'=>['required','integer'],
        ],[
            'terms.required'=>'Please accept the Terms of use and Privacy Policy',
            'country_id.required'=>'Cellphone Prefix is required'
        ]);



    }

    public function create(Request $request){
        $validated=$request->validate([
            'name'=>['required', 'string', 'max:255'],
            'last_name'=>['required', 'string', 'max:255'],
            'email'=>['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8'],
            'cellphone'=>['required','max:13','min:9'],
            'terms'=>['required','integer'],
            'country_id'=>['required','integer'],
            'role_id'=>['required','integer']
        ],[
            'terms.required'=>'Please accept the Terms of use and Privacy Policy',
            'country_id.required'=>'Please select your country',
            'role_id.required'=>'Select at at least one role'
        ]);



        $user=User::create([
            'name'=>$validated['name'],
            'last_name'=>$validated['last_name'],
            'email'=>$validated['email'],
            'password'=>Hash::make($validated['password']),
            'cellphone'=>$validated['cellphone'],
            'country_id'=>$validated['country_id'],
            'terms'=>$validated['terms'],
            'user_code'=>Str::upper(Str::random(6)),
        ]);

        //add user role
        $role=Role::findById($validated['role_id']);
        $user->assignRole($role);
        Auth::login($user);

        //create email verification token
        $token=rand(111111,999999);
        VerifyUser::create([
            'user_id'=>$user->id,
            'otp_code'=>$token
        ]);


        //event for email verification
        EmailVerify::dispatch($user,$token);
        return redirect()->route('verify');
    }


    public function login(){
        return inertia::render('login');
    }

    public function authenticate(Request $request){
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            $role=Auth::user()->getRoleNames()->first();
            switch ($role) {
                case($role=='Super-Admin'):
                    return redirect(RouteServiceProvider::HOME);
                    break;
                case($role=='Property-Manager'):
                    return redirect(RouteServiceProvider::MANAGER);
                    break;
                case($role=='Landlord'):
                    return redirect(RouteServiceProvider::LANDLORD);
                    break;
                case($role=='Staff'):
                    return redirect(RouteServiceProvider::STAFF);
                    break;
                case($role=='Tenant'):
                    return redirect(RouteServiceProvider::TENANT);
                case($role=='Caretaker'):
                    return redirect(RouteServiceProvider::CARETAKER);
                    break;
                default:
                    return redirect('/');
            }
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ])->onlyInput('email');

    }




}
