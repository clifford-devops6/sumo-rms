<?php

namespace App\Http\Controllers\Api;

use App\Events\EmailVerify;
use App\Http\Controllers\Controller;
use App\Http\Requests\Tenant\OTPCodeRequest;
use App\Http\Requests\Tenant\TenantLoginRequest;
use App\Http\Requests\Tenant\TenantPasswordResetRequest;
use App\Http\Requests\Tenant\TenantPasswordUpdateRequest;
use App\Http\Requests\Tenant\TenantRegisterRequest;
use App\Http\Requests\Tenant\TenantUpdateRequest;
use App\Models\Country;
use App\Models\User;
use App\Models\Verify\VerifyUser;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Role;

class TenantApiController extends Controller
{
    //get countries id
    public function countries(){
        $countries=Country::all();
        return response()->json([
            'countries'=>$countries,
            'messages'=>'Countries list successfully retrieved'
        ],200);
    }

    public function register(TenantRegisterRequest $request)
    {
        $user=User::create([
            'name'=>$request->name,
            'last_name'=>$request->last_name,
            'email'=>$request->email,
            'cellphone'=>$request->cellphone,
            'password'=>Hash::make($request->password),
            'user_code'=>Str::upper(Str::random(6)),
            'status'=>0,
            'country_id'=>$request->country_id,
            'terms'=>$request->terms,
        ]);

        //create email verification token
        $token=rand(111111,999999);
        VerifyUser::create([
            'user_id'=>$user->id,
            'otp_code'=>$token
        ]);
        //assign role
        $role=Role::where('name','Tenant')->firstOrFail();
        $user->assignRole($role);

        //event for email verification

        EmailVerify::dispatch($user,$token);
        return response()
            ->json(
                [
                    'message' => 'Registration Successful. Please check you email to verify your account',
                    'user'=>$user
                ],
                200);

    }


    public function login(TenantLoginRequest $request){

        $user=User::where('email',$request->email)->first();


        //Check if user is verified!
        if ($user){
             if (!$user->email_verified){
                 //send verification email to user and abort authentication
                 //create email verification token
                 $token=rand(111111,999999);
                 VerifyUser::create([
                     'user_id'=>$user->id,
                     'otp_code'=>$token
                 ]);
                 EmailVerify::dispatch($user,$token);
                 return  response()
                     ->json(
                         ['message' => 'User account not verified. Please check your email to verify account'],
                         200);
             }
        }else{
            return  response()
                ->json(
                    ['message' => 'The user does exist in our records'],
                    404);
        }

        //check if the credentials match!

        if (Hash::check($request->password, $user->password)){
            return response()
                ->json([
                    'message' => 'Login Success!',
                    'user'=>$user
                ], 200);
        }else{
            return  response()
                ->json(
                    ['message' => 'The provided credentials do not match our records.'],
                    401);
        }





    }

    public function update(TenantUpdateRequest $request,$id){
      //Update Except email:
        $user=User::find($id);
        if ($user){
            $user->update($request->all());
            return response()
                ->json([
                    'message'=>'User Updated Successfully',
                    'user'=>$user
                ], 200);
        }else{
            return response()
                ->json([
                    'message'=>'User does not exist in our database'
                ], 404);
        }

    }

    public function verification($id){
        //When user requests for a verification email

        $user=User::find($id);
        if ($user){
            $verifyUser = VerifyUser::where('user_id', $user->id)->first();
            if (!$verifyUser) {
                $otp_code = rand(1111,9999);
                $verifyUser = VerifyUser::create([
                    'tenant_id' => $id,
                    'otp_code' => $otp_code
                ]);
            }

            //event for email verification

            $otp_code=$verifyUser->otp_code;
            EmailVerify::dispatch($user,$otp_code);
            return response()
                ->json([
                    'message'=>'Email Verification Successfully sent'
                ], 200);
        }else{
            return response()
                ->json([
                    'message'=>'User does not exist in our database'
                ], 404);
        }
    }


    public function verifyUser(OTPCodeRequest $request, $id){
        $user=User::find($id);
        if ($user){
            $verifyUser = VerifyUser::where('user_id', $user->id)->where('otp_code', $request->otp_code)->first();
            if ($verifyUser) {

              $user->update(['email_verified'=>1]);
                return response()
                    ->json([
                        'message'=>'User verified Successfully'
                    ], 200);
            }else{
                return response()
                    ->json([
                        'message'=>'OTP Code not found in our databases'
                    ], 404);
            }

        }else{
            return response()
                ->json([
                    'message'=>'User does not exist in our database'
                ], 404);
        }

    }


    //Reset Tenant Password
    public  function resetPassword(TenantPasswordResetRequest $request){
      $user=User::where('email', $request->email)->firstOrFail();
        //create email verification token
        $token=rand(111111,999999);
        VerifyUser::create([
            'user_id'=>$user->id,
            'otp_code'=>$token
        ]);
       //event for email verification

        EmailVerify::dispatch($user,$token);
        return response()
            ->json(
                [
                    'message' => 'OTP Code has been sent your email. Please use the code to update your password',

                ],
                200);

    }

    public function storePassword(TenantPasswordUpdateRequest $request){

        $verifyUser=VerifyUser::where('otp_code', $request->otp_code)->firstOrFail();
        if(!is_null($verifyUser) ){
            if ($verifyUser->created_at>=Carbon::now()->subMinutes(15)){
                $user=$verifyUser->user;
                $user->password = Hash::make($request->password);

                return response()
                    ->json([
                        'message'=>'Password Reset successful!',

                    ], 200);
            }else{
                return  response()
                    ->json([
                        'message'=>'The OTP Code Provided is expired or invalid'
                    ],404);
            }
        }else{
            return response()
                ->json( [
                    'message'=>'Password Update Failed'
                ],404);
        }
    }

}
