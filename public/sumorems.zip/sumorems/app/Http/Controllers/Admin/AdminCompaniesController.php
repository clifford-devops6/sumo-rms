<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\CompanyCreateRequest;
use App\Http\Requests\CompanyUpdateRequest;
use App\Http\Resources\CompanyCollection;
use App\Http\Resources\CompanyResource;
use App\Models\Company;
use App\Models\Country;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Inertia\Inertia;



class AdminCompaniesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $companies=Company::with('user')->with('location')
            ->when(request('search'),function ($query,$search){
                $query->where('name','like', '%'.$search.'%');
            })
            ->paginate(10);
        $companies=CompanyResource::collection($companies);

        $filters=request()->only(['search']);
        return  inertia::render('admin.companies.index', compact('companies','filters'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $countries=Country::select(['name','id'])->get();
        return  inertia::render('admin.companies.create', compact('countries'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CompanyCreateRequest $request)
    {
        //
        $user=User::where('user_code', $request->manager_id)->firstOrFail();
        //create company
       $company=$user->company()->create([
           'name'=>$request->name,
           'email'=>$request->email,
           'contact_person'=>$request->contact_person,
           'cellphone'=>$request->cellphone


       ]);
       //add company location
       $company->location()->create([
           'country_id'=>$request->country_id,
           'city'=>$request->city,
           'street_address'=>$request->street_address
       ]);

       //store company logo

        if($file=$request->file('logo')) {
            $company->addMedia($file)->toMediaCollection('logo');
        }

        activity()
            ->causedBy(Auth::user())
            ->performedOn($company)
            ->useLog('companies')
            ->event('created')
            ->log('created ' .$company->name. ' file');

        return redirect()->route('companies.index')
            ->with('status','Company Created Successfully');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

        $company=new CompanyResource(Company::findBySlugOrFail($id));

        return inertia::render('admin.companies.show', compact('company'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $company=new CompanyResource(Company::findBySlugOrFail($id));
        $countries=Country::select(['name','id'])->get();
        return inertia::render('admin.companies.edit', compact('company','countries'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CompanyUpdateRequest $request, $id)
    {
        //

        $company=Company::findOrFail($id);
        $company->update([
            'name'=>$request->name,
            'email'=>$request->email,
            'contact_person'=>$request->contact_person,
            'cellphone'=>$request->cellphone
        ]);
        $company->location()->first()->Update([
            'country_id'=>$request->country_id,
            'city'=>$request->city,
            'street_address'=>$request->street_address
        ]);

        if($files=$request->file('logo')) {

            if ( $company->getMedia('logo')->count()>0){
                $company->clearMediaCollection('logo');
                $company->addMedia($files)->toMediaCollection('logo');
            }else{
                $company->addMedia($files)->toMediaCollection('logo');
            }

        }
        activity()
            ->causedBy(Auth::user())
            ->performedOn($company)
            ->useLog('companies')
            ->event('updated')
            ->log('Updated ' .$company->name. ' file');
       return redirect()->route('companies.index')
           ->with('status','Company file successfully updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
