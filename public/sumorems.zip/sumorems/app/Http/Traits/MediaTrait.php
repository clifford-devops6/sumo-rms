<?php

namespace App\Http\Traits;

use Intervention\Image\Facades\Image;

trait MediaTrait
{
    public $path;

    public function __construct(){
        $this->path=public_path().'/files/';
    }
   /*
    * Save media will require tag, and file path
    */
    public function addMediaCollection($file, $collection):void
    {
        $file_name=$file->getClientOriginalName();
        $image = Image::make($file);
        $image->save($this->path.$file_name);




       $this->media()->create([
           'file_name'=>$file_name,
           'model_type'=>static::class,
           'model_id'=>$this->id,
           'collection'=>$collection
       ]);


    }







}
