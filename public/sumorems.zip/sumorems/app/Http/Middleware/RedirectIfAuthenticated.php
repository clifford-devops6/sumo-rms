<?php

namespace App\Http\Middleware;

use App\Providers\RouteServiceProvider;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RedirectIfAuthenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @param  string|null  ...$guards
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next, ...$guards)
    {
        $guards = empty($guards) ? [null] : $guards;

        foreach ($guards as $guard) {
            if (Auth::guard($guard)->check()) {
                $role=Auth::user()->getRoleNames()->first();
                switch ($role) {
                    case($role=='Super-Admin'):
                        return redirect(RouteServiceProvider::HOME);
                        break;
                    case($role=='Property-manager'):
                        return redirect(RouteServiceProvider::MANAGER);
                        break;
                    case($role=='Landlord'):
                        return redirect(RouteServiceProvider::LANDLORD);
                        break;
                    case($role=='Staff'):
                        return redirect(RouteServiceProvider::STAFF);
                        break;
                    case($role=='Tenant'):
                        return redirect(RouteServiceProvider::TENANT);
                    case($role=='Caretaker'):
                        return redirect(RouteServiceProvider::CARETAKER);
                        break;
                    default:
                        return redirect('/');
                }
            }
        }

        return $next($request);
    }
}
